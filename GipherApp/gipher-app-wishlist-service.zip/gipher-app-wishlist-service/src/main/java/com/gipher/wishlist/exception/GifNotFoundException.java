package com.gipher.wishlist.exception;

public class GifNotFoundException extends Exception {

	public GifNotFoundException(String message) {
		super(message);
	}
}
